import React from 'react';
import './App.css';

import NodeDragTry from './components/NodeDragTry.js';
import logo from './logo.svg';
import Login from './components/Login';
import NodeComponent from './components/NodeComponent'

function App() {
  return (
    <div className="App">
     {/*<NodePath/>*/}
      {/*<NodeDragTry/>*/}
      <NodeComponent/>
    </div>
  );
}

export default App;
