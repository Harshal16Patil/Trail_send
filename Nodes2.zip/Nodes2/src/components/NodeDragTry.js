import React, { useState, useRef, Component, useEffect } from 'react';
import { NodeContext, NodeProvider,NodeConsumer } from '../NodeContext';
import ReactFlow, {
  ReactFlowProvider,
  addEdge,
  removeElements,
  Background,
  Controls,
} from 'react-flow-renderer';
import SplitPane from "react-split-pane";
import Sidebar from './NodeSidebar';
import NodeComponent from './SideBar'




const label=(type)=>{
  if(type==='input'){
    return "data_labels";
  }
  else if(type==='default'){
    return "augmentation";
  }
  else{
    return "training_params";
  }
}
const initialElements = [
  {
    id: '1',
    type: 'input',
    data: { label: label('input') },
    position: { x: 250, y: 5 },
  },
];

let id = 0;
const getId = () => `dndnode_${id++}`;

const DnDFlow =()=>{
  const [state,setState]=useState("false");
    const reactFlowWrapper = useRef(null);
    const [reactFlowInstance, setReactFlowInstance] = useState(null);
    const [elements, setElements] = useState(initialElements);

    const onConnect = (params) => setElements((els) => addEdge(params, els));
    const onElementsRemove = (elementsToRemove) =>
      setElements((els) => removeElements(elementsToRemove, els));
  
    const onLoad = (_reactFlowInstance) =>
      setReactFlowInstance(_reactFlowInstance);
  
    const onDragOver = (event) => {
      event.preventDefault();
      event.dataTransfer.dropEffect = 'move';
    };
  
    const onDrop = (event) => {
      event.preventDefault();
  
      const reactFlowBounds = reactFlowWrapper.current.getBoundingClientRect();
      const type = event.dataTransfer.getData('application/reactflow');
      const position = reactFlowInstance.project({
        x: event.clientX - reactFlowBounds.left,
        y: event.clientY - reactFlowBounds.top,
      });
      const newNode = {
        id: getId(),
        type,
        position,
        data: { label: label(type)},
      };
  
      setElements((es) => es.concat(newNode));
    };
    
   
    //const [nodeLabelState,setNodeLabelState]=useState(null)
    //const [trailNodeState,setTrailNodeState]=useState('')
    const [clickState,setCliclState]=useState(false)
    useEffect(()=>{

    },[])


    useEffect(()=>{})
    

  const Data='data_labels';
  const Training ='training_params';
  const Augmentation='augmentation';

    
    

    const [nodeLabelState,setNodeLabelState]=useState(null)

    const onElementClick = (event, element) => {
       
      console.log('click', element);
     /* setTrailNodeState([element.data.label])
      console.log(trailNodeState)*/
      //console.log(element.data.label)
      setNodeLabelState(element.data.label)
      setState('true');
      
      
      
    };
    
    
    const onPaneClick=(event)=>{
      setState('false')
    }
     return (
      <NodeProvider value={{nodeLabelState:nodeLabelState}}>
      
      <div>
        <SplitPane split="vertical"  minSize={1150} >
       
          <div className="dndflow">
            <ReactFlowProvider>
                <SplitPane split="vertical"  minSize={300} >
                 <Sidebar />
                 <div className="reactflow-wrapper" ref={reactFlowWrapper}>
                    <ReactFlow
                      elements={elements}
                      style={{height:500}}
                      onConnect={onConnect}
                      onElementsRemove={onElementsRemove}
                      onLoad={onLoad}
                      onDrop={onDrop}
                      onDragOver={onDragOver}
                      onElementClick={onElementClick}
                      onPaneClick={onPaneClick}
                    >
                    <Controls />
                    <Background/>
                    
                    </ReactFlow>
                  </div>
        
                </SplitPane>
              </ReactFlowProvider>
     
          </div>
          {
            (()=>{
              if(state==='true'){
                return <NodeComponent/>
              }
              else{
                return null;
              }
            })()
          }
          
       </SplitPane>
    </div>
    </NodeProvider>
  );
  
};

export default DnDFlow;