import React, {useContext} from 'react'
import Checkbox from './elements/Checkbox';
import Input from './elements/Input';
import Button from './elements/Button';
import Select from './elements/Select';
import { FormContext, FormProvider,FormConsumer } from '../FormContext';
import HiddenControl from './elements/HiddenControl';
import { useEffect } from 'react/cjs/react.development';


const Element = (props) => {

    const { readonly,innerControls,label, type,property, required,reset,placeholder,value,isSingle,options}=props.field
    const { stateButton,setStateButton } = useContext(FormContext)
    //console.log(type)
    /*var options=props.options
    if(label==='Select instance type')
    {
        options =props.options.instance_type
    }
    else if(label==='Select optimizer'){
        options =props.options.optimizer
    }
    //console.log(label)
    /*if(options!==undefined){console.log(options)
    }
else{console.log(0)}*/
if(true){
    //console.log("Hi")
   switch (type) {
        case 'text':
            return (<Input
                field_type={type}
                field_label={label}
                field_placeholder={placeholder}
                field_value={value}
                field_property={property}
                field_required={required}
                field_reset={reset}
            />)
        case 'submitButton':
           
            return (<Button
                    field_type={type}
                    field_label={label}
                />)
        case 'dropdown':
            return (<Select
                field_type={type}
                field_label={label}
                field_placeholder={placeholder}
                field_value={value}
                field_property={property}
                field_required={required}
                field_reset={reset}
                field_isSingle={isSingle}
                field_options={options}

            />)
        case 'formArray':
            return (<div>
                    <label htmlFor="exampleInputEmail1" className="form-label">{label}</label>
                    
                    {innerControls ? innerControls.map((field, i) => <Element key={i} field={field} /*options={options}*/ />) : null}
              

                </div>)
        case 'checkbox':
                return (<Checkbox
                    
                    field_label={label}
                    field_value={value}
                    field_required={required}
                    field_readonly={readonly}
            />)
        
        case 'number':
            return (<Input
                field_type={type}
                field_label={label}
                field_placeholder={placeholder}
                field_value={value}
                field_property={property}
                field_required={required}
                field_reset={reset}
            />)
        
        case 'hiddenControl':
            return (
                
                <FormConsumer>
                {
                    
                  ({stateCheck,checkClick})=>{
                    return( <div>
                        
                        <HiddenControl 
                            field_label={label}
                            field_value={value}
                            field_readonly={readonly}
                            />
                    { (()=>{
                        var hiddenOptions=[]
                        if(stateCheck===true&&innerControls!==undefined){
                         Object.values(innerControls).forEach((field, i) => hiddenOptions.push(<Element key={i} field={field} /*options={options}*/ />)) 
                         return hiddenOptions;
                        }else{
                            return null;
                        }
                    })()
                    }
                    </div>
                    )
                  }
               
              }
              </FormConsumer>
            )

        default:
            return null;
    }
}
else{
    return null;
}

}

export default Element
