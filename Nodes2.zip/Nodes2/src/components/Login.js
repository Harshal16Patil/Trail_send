import Reactform from "react";
import { useState, useEffect,useContext,useRef } from 'react';

const Login=({props})=>{
    const [emailState,setEmailState]=useState("");
    const [passwordState,setPasswordState]=useState("")
    const {email,
        password,
        setpassword,
        handleLogin,
        handleSignup,
        hasAccount,
        setHasAccount,
        emailError,
        passwordError}=[];
    
    const inputRef=useRef(null)
    const setEmail=(event)=>{
        setEmailState(event.target.value)
        console.log(emailState)
    }
    const setPassword=(event)=>{
        setPasswordState(event.target.value)
        console.log(passwordState)
    }

    useEffect(()=>{
        inputRef.current.focus()
    },[])

    return(
    <section className="login">
        <div className="loginContainer">
            <label>UserName</label>
            <input ref={inputRef}type="text" 
        
            required 
            value={email}
            onChange={(event)=>setEmail(event)}  />
            <p className="errorMsg">{emailError}</p>
            <label>Password</label>
            <input type="password" 
            autoFocus 
            required 
            value={password}
            onChange={(e)=>setPassword(e)}  />
            <p className="errorMsg">{passwordError}</p>

            <div className="btnContainer">
                { hasAccount ?(
                    <>
                    <button onClick={handleLogin}>Sign In</button>
                    <p>Don't have an account? <span onClick={()=>setHasAccount(!hasAccount)}>Sign up</span></p>
                    </>
                ):(
                    <>
                    <button onClick={handleSignup}> </button>
                    <p>Have an account? <span onClick={()=>setHasAccount(!hasAccount)}>Sign up</span></p>
                    </>
                )}
                
            </div>
        </div>
    </section>
    );
};

export default Login;