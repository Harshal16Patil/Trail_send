import React from 'react';
import './NodeSidebar.css';

export default () => {
  const onDragStart = (event, nodeType) => {
    event.dataTransfer.setData('application/reactflow', nodeType);
    event.dataTransfer.effectAllowed = 'move';
  };

  return (
    <div class='container'>
    <aside >
      <div className="description">You can drag these nodes to the pane on the right.</div>
      <div className="dndnode-input" onDragStart={(event) => onDragStart(event, 'input')} draggable>
       data_labels
      </div>
      <div className="dndnode" onDragStart={(event) => onDragStart(event, 'default')} draggable>
       augmentation
      </div>
      <div className="dndnode-output" onDragStart={(event) => onDragStart(event, 'output')} draggable>
         training_params
      </div>
      
    </aside>
    </div>
  );
};