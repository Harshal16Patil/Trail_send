import React from 'react';
import { createContext } from 'react';


const NodeContext = createContext(null);

const NodeProvider = NodeContext.Provider
const NodeConsumer = NodeContext.Consumer

export {NodeProvider, NodeConsumer,NodeContext}
