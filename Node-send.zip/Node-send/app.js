const express=require('express');
const http=require("http")
const cors=require("cors")
//const proxy= require('http-proxy-middleware')
const app=express();
const { OAuth2Client } = require('google-auth-library');
const { response } = require('express');
const client = new OAuth2Client("881458096689-beugkqj0c83vf7qspd114bgj979hsq4f.apps.googleusercontent.com")

app.use(cors({
    origin:'*',
    credentials:true,
}))
app.all('*',(req,res,next)=>{
    res.header('Access-Control-Allow-Origin','*');
    res.header('Access-Control-Allow-Methods','*');
    res.header('Access-Control-Allow-Headers','*');
    res.header('Access-Control-Allow-Crendentials',true);
   /* req.header('Access-Control-Allow-Origin','*');
    req.header('Access-Control-Allow-Methods','PUT, GET, POST, DELETE, OPTIONS');
    req.header('Access-Control-Allow-Headers','*');
    req.header('Access-Control-Allow-Crendentials',true);*/
})

app.post("/api/v1/auth/google", async (req, res) => {
    const { tokenId }  = req.body
    console.log("token" + tokenId)
    const ticket = await client.verifyIdToken({
        idToken: tokenId,
        audience: "881458096689-beugkqj0c83vf7qspd114bgj979hsq4f.apps.googleusercontent.com"
    }).then(response=>{
        const { name, email, picture } = response.getPayload(); 
        console.log("Payload"+response)   
    });
    //const { name, email, picture } = ticket.getPayload();      
    //console.log(name)
    /*const user = await db.user.upsert({ 
        where: { email: email },
        update: { name, picture },
        create: { name, email, picture }
    })*/
    res.status(201)
    res.json(user)
})
app.listen(8080,(req,res)=>{
  console.log("running");
});